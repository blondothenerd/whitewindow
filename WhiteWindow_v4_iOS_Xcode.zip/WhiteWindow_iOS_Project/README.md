# White Window v3.1 — iOS Landscape Edition

**Landscape-only native app:** `Info.plist` restricts iPhone and iPad to landscape left/right. A real rotation can be enforced by the iOS app, unlike a Safari or Messenger web page. The native app still requires compiling/signing with Xcode on macOS.

**Safari/Messenger browser edition:** `WhiteWindow_Landscape_iOS_v3_1.html` rotates the complete game UI (3D scene, touch controls and menus) visually by 90 degrees when held upright. It cannot change the phone's system orientation. Messenger may block opening external browsers; use its menu to open externally or copy an HTTPS URL into Safari. Sending a raw HTML file in Messenger is not a reliable webpage hosting method. Upload to an HTTPS host and share the URL.

**Graphics:** The 3D mode loads Three.js from a CDN. Without network access or when WebGL/module loading is blocked, it uses its playable 2D renderer. The native project bundles the HTML and has the same fallback; 3D is not guaranteed offline.

**Build:** Open `WhiteWindow.xcodeproj` in Xcode 16+, select your signing team, pick iPhone/iPad or simulator and click Run. For an IPA, Product → Archive → Distribute App. iOS 16+ target. No signed IPA is provided.

**Verification:** HTML JavaScript was syntax-checked in Node; plist parsed; Xcode compilation and real-device touch testing are not available in the current environment.

# White Window — Neon Highway (iOS source)

## Run on iPhone / iPad
1. On a Mac, open `WhiteWindow.xcodeproj` in Xcode 16 or newer.
2. Select the WhiteWindow app target > Signing & Capabilities, choose your Apple developer team, and use your own unique bundle identifier if necessary.
3. Plug in your iPhone (or select an iOS Simulator), choose the device, and press Run (▶).
4. For a distributable .ipa use Xcode Product > Archive, then Distribute App with your appropriate signing account.

This is the *source project*, not a signed `.ipa`. It cannot be compiled or run-tested on an iPhone in this Linux environment.

## Graphics and offline behavior
The native WKWebView contains the full game HTML (Game/index.html). On a normal HTTPS site the game downloads Three.js to enable the upgraded 3D renderer. If Three.js cannot be loaded, the built-in playable 2D game starts automatically. When opening directly from an iOS app bundle, module loading may be restricted; the 2D fallback is available. For guaranteed offline 3D, Three.js should be bundled and served via a verified custom URL scheme or a supported app-local HTTP server; this release does **not** claim offline 3D on native iOS.

For the browser version, host the HTML over HTTPS; opening the file via Files may block remote modules in some browsers. iOS Safari > Share > Add to Home Screen gives a standalone shortcut, though it is still a web app.

## Privacy
No accounts or advertising. Leaderboards are stored in the local WebKit/browser storage where available.
