import SwiftUI
import WebKit

@main
struct WhiteWindowApp: App {
    var body: some Scene {
        WindowGroup {
            GameView()
                .background(Color(red: 0.02, green: 0.05, blue: 0.09))
                .ignoresSafeArea()
                .statusBarHidden()
        }
    }
}

struct GameView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.02, green: 0.05, blue: 0.09, alpha: 1)
        web.scrollView.isScrollEnabled = false
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = false
        if let index = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Game") {
            web.loadFileURL(index, allowingReadAccessTo: index.deletingLastPathComponent())
        } else {
            web.loadHTMLString("<h2>White Window game assets are missing.</h2>", baseURL: nil)
        }
        return web
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
